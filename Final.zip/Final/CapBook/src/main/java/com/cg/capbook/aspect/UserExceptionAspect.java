package com.cg.capbook.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.capbook.customresponse.CustomResponse;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

@ControllerAdvice(basePackages="com.cg.capbook.controllers")
public class UserExceptionAspect {
	@ExceptionHandler(UserDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse> handleUserDetailsNotFoundException(Exception e){
		CustomResponse response=new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<CustomResponse>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(SameUserIdException.class)
	public ResponseEntity<CustomResponse> handleSameUserIdException(Exception e){
		CustomResponse response = new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<CustomResponse>(response,HttpStatus.EXPECTATION_FAILED);
	}
}
