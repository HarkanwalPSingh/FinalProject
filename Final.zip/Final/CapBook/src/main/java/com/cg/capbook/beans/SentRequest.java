package com.cg.capbook.beans;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
@Entity
@SequenceGenerator(name="seq3", initialValue=1, allocationSize=100)
public class SentRequest {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq3")
	private int id3;
	private int sentRequestId;
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
	public int getSentRequestId() {
		return sentRequestId;
	}
	public void setSentRequestId(int sentRequestId) {
		this.sentRequestId = sentRequestId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public SentRequest(int sentRequestId, User user) {
		super();
		this.sentRequestId = sentRequestId;
		this.user = user;
	}
	public SentRequest() {
		super();
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + sentRequestId;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SentRequest other = (SentRequest) obj;
		if (sentRequestId != other.sentRequestId)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
}
