package com.cg.capbook.controllers;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capbook.beans.Messages;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

@RestController
@CrossOrigin
public class CapBookController {
	@Autowired 
	private UserServices userServices;

	@RequestMapping(value="/register", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> registerUserAction(@RequestBody User user) {
		if(userServices.userExists(user))
			return new ResponseEntity<String>("User already exists", HttpStatus.CONFLICT);
		else {
			userServices.registerUser(user);
			return new ResponseEntity<String>("User successfully added", HttpStatus.OK);
		}
	}
	@RequestMapping(value="/login", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> loginUserAction(@RequestBody User user) throws IncorrectPasswordException, UserDetailsNotFoundException{
		user = userServices.loginUser(user.getEmailId(), user.getPassword());
		return new ResponseEntity<>(user,HttpStatus.OK);
	}

	@RequestMapping(value="/getUserDetails",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<User> getUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		User user=userServices.getUserDetails(userId);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	@RequestMapping(value="/getUserId",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<User> getUserIdAction(@RequestParam("emailId") String emailId){
		User user = userServices.getUserId(emailId);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	
	@RequestMapping(value="/editUserDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> editUserAction(@RequestBody User editUser) throws UserDetailsNotFoundException {
		User user = userServices.getUserDetails(editUser.getUserId());
		user.setFirstName(editUser.getFirstName());
		user.setLastName(editUser.getLastName());
		user.setAddress(editUser.getAddress());
		
		user=userServices.editUserDetails(user);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	@RequestMapping(value="/deleteUserDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		userServices.deleteUserAccount(userId);
		return new ResponseEntity<String>("User details have been deleted successfully",HttpStatus.OK);
	}
	@RequestMapping(value="/addBulkUserDetails",consumes=MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.POST)
	public ResponseEntity<String> addBulkUserDetails(@RequestBody ArrayList<User> users){
		for(User user:users)
			userServices.registerUser(user);
		return new ResponseEntity<>("user details successfully added",HttpStatus.OK);
	}
	@RequestMapping(value="/getAllUsers",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<User>> getUserAction() throws UserDetailsNotFoundException {
		List<User> users=userServices.getAllUserDetails();
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	@RequestMapping(value="/sendRequest",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<String> sendRequest(@RequestParam ("userIdSender") int userIdSender,
			@RequestParam ("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException, SameUserIdException, RequestAlreadySentException{
		userServices.sendFriendRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request sent",HttpStatus.OK);
	}
	@RequestMapping(value="/acceptRequest",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<String> acceptRequest(@RequestParam("userIdSender") int userIdSender,
			@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		userServices.acceptFriendRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request accepted",HttpStatus.OK);
	}
	@RequestMapping(value="/cancelRequest",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<String> cancelRequest(@RequestParam("userIdSender") int userIdSender,
			@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		userServices.cancelSentRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request cancelled",HttpStatus.OK);
	}
	@RequestMapping(value="/rejectRequest",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<String> rejectRequest(@RequestParam("userIdSender") int userIdSender,
			@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		userServices.rejectRequest(userIdSender, userIdreceiver);
		return new ResponseEntity<>("request rejected",HttpStatus.OK);
		}
	@RequestMapping(value="/friendRequestsList",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<List<User>> getfriendRequestList(@RequestParam("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		List<User> users = userServices.getFriendRequests(userIdreceiver);
		return new ResponseEntity<List<User>>(users,HttpStatus.OK);
	}
	@RequestMapping(value="/friendsList",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<List<User>> getfriendsList(@RequestParam("userId") int userId) throws UserDetailsNotFoundException{
		List<User> users = userServices.getFriendsList(userId);
		return new ResponseEntity<List<User>>(users,HttpStatus.OK);
	}
	@RequestMapping(value="/sendMessage",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<String> sendMessage(@RequestParam ("userIdSender") int userIdSender,@RequestParam("userIdreceiver") int userIdreceiver,
			@RequestParam("message") String message) throws UserDetailsNotFoundException{
		userServices.sendMessage(userIdSender, userIdreceiver, message);
		return new ResponseEntity<String>("message is sent",HttpStatus.OK);
	}
	@RequestMapping(value="/getSentMessages",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<List<Messages>> getSentMessage(@RequestParam ("userIdSender") int userIdSender) throws UserDetailsNotFoundException{
		return new ResponseEntity<List<Messages>>(userServices.getSentMessages(userIdSender),HttpStatus.OK);
	}
	@RequestMapping(value="/getReceivedMessages",produces = MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.GET)
	public ResponseEntity<List<Messages>> getReceivedMessage(@RequestParam ("userIdreceiver") int userIdreceiver) throws UserDetailsNotFoundException{
		return new ResponseEntity<List<Messages>>(userServices.getReceivedMessages(userIdreceiver),HttpStatus.OK);
	}
	

	
}