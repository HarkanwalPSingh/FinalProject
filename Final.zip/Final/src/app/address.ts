export interface Address {
    city:string,
    state:string,
    country:string
}
