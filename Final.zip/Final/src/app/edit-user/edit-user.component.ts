import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { EditUser } from '../edit-user';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  user:User
  editUser: EditUser
  errorMessage:string
  successMessage:string
  _firstName:string
  _lastName:string
  _city:string
  _state:string
  _country:string
  _file:File
  constructor(private router:Router,private userServices : UserService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.editUser=JSON.parse(localStorage.getItem("user"))
    
  }
  get firstName():string{
    return this._firstName
  }
  
  set firstName(value:string){
    this._firstName=value
  }
  get lastName():string{
    return this._lastName
  }
  
  set lastName(value:string){
    this._lastName=value
  }

  get city():string{
    return this._city
  }

  set city(value:string){
    this._city=value
  }

  get state():string{
    return this._state
  }

  set state(value:string){
    this._state=value
  }

  get country():string{
    return this._country
  }

  set country(value:string){
    this._country=value
  }

  get file():File{
    return this._file
  }

  set file(value:File){
    this._file=value
  }

  onSubmit(){
    let obj=
      {
        "userId":this.editUser.userId,
        "firstName":this._firstName,
        "lastName":this._lastName,
        "emailId":this.editUser.emailId,
        "address":{
        "city":this._city,
        "state":this._state,
        "country":this._country
        }
        
      }
console.log(obj)

    this.userServices.editUser(obj).subscribe(
      user=>{
        this.user=user

        console.log("Successfully Edited")
        console.log(this.user);
        
        localStorage.setItem('user', JSON.stringify(this.user))
        console.log(user)
      },
      message=>{
        this.errorMessage=message
        console.log("Edit Failed")
      }
    )
    this.router.navigate(['/wall'])
  }

  uploadFile(){
    console.log(this._file);
    let body = new FormData();
    // Add file content to prepare the request
    body.append("file", this._file);
    this.userServices.uploadPhoto(body).subscribe(
      message=>{
        // this.successMessage=message
        console.log("Successfully Uploaded");
        
      },
      message=>{
        this.errorMessage=message
        console.log("Upload Failed")
      }
    )
  }
  

}
