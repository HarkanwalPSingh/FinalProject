import { Component, OnInit } from '@angular/core';
import { User } from '../user'
import { UserService } from '../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Message } from '../message';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {

  constructor(private userService:UserService, private route:ActivatedRoute,private router:Router) { }
  users:User[];
  user:User;
  errorMessage:string;
  userIdSenderSentMessages:number;
  userIdreceiverSentMessages:number;
  userIdreceiverReceivedMessages:number;
  userIdSenderReceivedMessages:number;
  message:Message;
  messagesSent:Message[];
  messagesReceived:Message[];
  firstName:string
  lastName:string
  senderName:string
  
  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem("user"));
    this.userIdSenderSentMessages=this.user.userId;
    this.userIdreceiverReceivedMessages=this.user.userId;
    this.senderName = this.firstName + this.lastName;
    this.userService.getSentMessages(this.userIdSenderSentMessages).subscribe(
      tempMessages=>{
        this.messagesSent=tempMessages;
      },
      error=>{
        this.errorMessage=error;
      }
    )

    this.userService.getReceivedMessages(this.userIdreceiverReceivedMessages).subscribe(
      tempMessages=>{
        this.messagesReceived=tempMessages;
      },
      error=>{
        this.errorMessage=error;
      }
    )
    
  }
  // sendMessage(userIdSender:number,userIdreceiver:number){
  //   this.userService.sendMessage(userIdSender,userIdreceiver).subscribe(

  //   )
  // }

}